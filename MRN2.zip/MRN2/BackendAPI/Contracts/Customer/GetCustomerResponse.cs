﻿namespace BackendAPI.Contracts
{
    public class GetCustomerResponse
    {

        public int Id { get; set; }
        public string? Name { get; set; }

    }

}