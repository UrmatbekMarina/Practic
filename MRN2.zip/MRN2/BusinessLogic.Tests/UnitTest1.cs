using Moq;
using System;
using System.Threading.Tasks;
using Xunit;



namespace BusinessLogic.Tests
{
    public class UnitTest1
    {
        [Fact]
        public async Task CreatAsync_NullUser_ShouldThrowNullArgumentException()
        {
            var ex = await Assert.ThrowsAnyAsync<ArgumentNullException>(() => service.Create(null));
            Assert.IsType<ArgumentNullException>(ex);
            userRepositoryMoq.Verify(x => x.Create(It.IsAny<User>()), Times.Never);
        }
    }
}