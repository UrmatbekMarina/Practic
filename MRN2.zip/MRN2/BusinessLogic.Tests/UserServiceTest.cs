﻿using BusinessLogic.Services;
using Domain.Interfaces;
using Moq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BusinessLogic.Tests;


namespace BusinessLogic.Tests
{
    public class UserServiceTest
    {
        private readonly UserService service;
        private readonly Mock<IUserRepository> userRepositoryMoq;
        public UserServiceTest()
        {
            var userService = new Mock<IUserRepository>();
            userRepositoryMoq = new Mock<IUserRepository>();
            userRepositoryMoq.Setup(x => x.User).Returns(userRepositoryMoq.Object);
            service = new UserService(repositoryWrapper.Object);
        }
    }
}
